#include <utility>
#include <vector>
using namespace std;

pair<int, int> chiedi(int x) {
    return {0, 0};
}

void cambia(int x, int h) {
    return;
}

void inizializza(int N, vector<int> H) {
	return;
}

