import java.util.Scanner;

public class grader {

	// Declaring variables
	int R;
	int[] risultato1;
	int[] risultato2;

	muraglia mur; // user-defined

	void leggi_eventi(int M, Scanner scn) {
		int[] pair = new int[2];
		for (int i = 0; i < M; i++) {
			String tipo = scn.next();

			if (tipo.equals("Q")) {
				int x = scn.nextInt();
				mur.chiedi(x, pair);
				risultato1[R] = pair[0];
				risultato2[R] = pair[1];
				R++;
			} else {
				int x = scn.nextInt();
				int h = scn.nextInt();
				mur.cambia(x, h);
			}
		}
	}


	public static void main(String[] args) {
		grader grad = new grader();
		grad.mainLoop();
	}

	void mainLoop() {
		Scanner scn = new Scanner(System.in);

		// Reading input
		int N = scn.nextInt();
		int M = scn.nextInt();

		int[] H = new int[N];
		risultato1 = new int[M];
		risultato2 = new int[M];

		for (int i = 0; i < N; i++) {
			H[i] = scn.nextInt();
		}

		mur = new muraglia();
		
		// Calling functions
		mur.inizializza(N, H);
		leggi_eventi(M, scn);

		// Writing output
		for (int i = 0; i < R; i++) {
			System.out.print(risultato1[i]);
			System.out.print(' ');
			System.out.println(risultato2[i]);
		}
	}
}
