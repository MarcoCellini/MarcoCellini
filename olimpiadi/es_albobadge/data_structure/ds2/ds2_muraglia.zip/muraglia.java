public class muraglia {

    void chiedi(int x, int[] startEnd) {
        startEnd[0] = 0; // start
        startEnd[1] = 0; // end
    }

    void cambia(int x, int h) {
    }

    void inizializza(int N, int[] H) {
    }

}
