void aggiungi(long long int id) {
    
}

void togli(long long int id) {
    
}

int conta(long long int id) {
    return 42;
}

