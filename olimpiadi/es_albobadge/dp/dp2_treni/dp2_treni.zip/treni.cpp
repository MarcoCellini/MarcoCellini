int tempo_massimo(int N, int a[], int b[])
{
    return 42;
}
