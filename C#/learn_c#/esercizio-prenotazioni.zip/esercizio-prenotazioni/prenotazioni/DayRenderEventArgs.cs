﻿namespace prenotazioni
{
    public class DayRenderEventArgs
    {
        public object Day { get; internal set; }
    }
}